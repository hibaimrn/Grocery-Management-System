#include "Manager.h"
#include "Menu.h"

Store Manager::getStore() {
    return store;
}
void Manager::setStore(Store s) {
    store = s;
}
void Manager::addInventory() {
    Menu m;
    Inventory i;
    fstream f;
    string name;
    int quantity;
    cout << "Enter Item Name";
    cin >> name;
    cout << "Enter Item Quantity";
    cin >> quantity;
    i.setname(name);
    i.setQuantity(quantity);
    f.open("inventory.txt", ios::out | ios::app);
    f << i.getname() << " " << i.getQuantity() << "\n";
    f.close();
    m.managerLogin();
}
void Manager::deleteInventory() {
    Menu m;
    string name;
    cout<<"Enter name of the product to delete";
    cin >> name;
    fstream f;
    f.open("inventory.txt", ios::in);
    fstream f1;
    f1.open("temp.txt", ios::out);
    string c;
    string line;
    while (getline(f, line)) {
        int j = 0;
        string s = "";
        for (int i = 0; i < line.size(); i++) {
            if (line[i] == ' ') {
               // c = stoi(s);
                if (c != name) {
                    f1 << line << "\n";
                    break;
                }
                else {
                    s = "";
                    break;
                }
            }
            else {
                s += line[i];
            }
        }
    }
    f.close();
    f1.close();
    remove("inventory.txt");
    rename("temp.txt", "inventory.txt");
    m.managerLogin();
}
void Manager::searchInventory() {
    Menu m;
    string name;
    cout << "Enter Id of the product to search";
    cin >> name;
    fstream f;
    f.open("inventory.txt", ios::in);
    string c;
    string line;
    while (getline(f, line)) {
        int j = 0;
        string s = "";
        Inventory i;
        for (int j = 0; j < line.size(); j++) {
            if (line[j] == ' ') {
                //c = stoi(s);
                if (c == name) {
                   i.setname(c);
                    s = "";
                }
                else {
                    s = "";
                    break;
                }
            }
            else {
                s += line[j];
            }
        }
    }
    f.close();
    m.managerLogin();
}