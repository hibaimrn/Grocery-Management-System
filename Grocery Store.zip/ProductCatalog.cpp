#include "ProductCatalog.h"
void ProductCatalog::setId(int id) {
	this->id = id;
}
int ProductCatalog::getId() {
	return id;
}
void ProductCatalog::setPrice(int price) {
	this->price = price;
}
int ProductCatalog::getPrice() {
	return price;
}
void ProductCatalog::setQuantity(int quantity) {
	this->quantity = quantity;
}
int ProductCatalog::getQuantity() {
	return quantity;
}
void ProductCatalog::setName(string name) {
	this->name = name;
}
string ProductCatalog::getName() {
	return name;
}
void ProductCatalog::setData(string name,int quantity,int price) {
	this->name;
	this->quantity;
	this->price;
}
string ProductCatalog::getData() {
	return name;
}