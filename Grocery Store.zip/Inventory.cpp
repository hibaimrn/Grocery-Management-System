#include "Inventory.h"
void Inventory::setname(string id) {
	this->name = name;
}
string Inventory::getname() {
	return name;
}
void Inventory::setQuantity(int quantity) {
	this->quantity = quantity;
}
int Inventory::getQuantity() {
	return quantity;
}