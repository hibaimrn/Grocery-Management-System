#include "Store.h"
string Store::getStoreName() { 
	return store_name; 
}
string Store::getStoreManager() { 
	return store_manager;
}
string Store::getStoreLocation() {
	return store_location;
}
void Store::setStoreName(string name) {
	store_name = name; 
}
void Store::setStoreManager(string manager) {
	store_manager = manager; 
}
void Store::setStoreLocation(string location) {
	store_location = location;
}