#pragma once
#include <iostream>
#include <string>
using namespace std;
class Inventory
{
	string name;
	int quantity;
public:
	void setname(string);
	string getname();
	void setQuantity(int);
	int getQuantity();
};

