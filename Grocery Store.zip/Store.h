#pragma once
#include <string>
using namespace std;
class Store
{
private:
    string store_name;
    string store_manager;
    string store_location;
public:
    string getStoreName();
    string getStoreManager();
    string getStoreLocation();
    void setStoreName(string name);
    void setStoreManager(string manager);
    void setStoreLocation(string location);
};

