#pragma once
#include <iostream>
#include <string>
using namespace std;
class ProductCatalog
{

	int id;
	int price=0;
	int quantity=0;
	string name;
public:
	void setId(int);
	int getId();
	void setPrice(int);
	int getPrice();
	void setQuantity(int);
	int getQuantity();
	void setName(string);
	string getName();
	void setData(string, int, int);
	string getData();

};

