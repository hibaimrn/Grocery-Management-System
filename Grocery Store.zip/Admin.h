#pragma once
#include <iostream>
#include <string>
#include "ProductCatalog.h"
#include <fstream>
#include "Menu.h"
#include "User.h"
using namespace std;
class Admin :public User
{
public:
    void addProduct();
    void deleteProduct();
    void searchProduct();
    void manageStoresAndUsers();
    void manageProductCatalog();
   
};

