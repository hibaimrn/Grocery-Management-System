#include<iostream>
#include "Menu.h"
using namespace std;
class Grocerystore
{
	Menu m;
public:
	void startprogram();

public:
	friend void Menu::displayMainMenu();
};
void Grocerystore::startprogram()
{
	 m.displayMainMenu();

}

int main() {
	Menu m;
	Grocerystore g;
	g.startprogram();
	system("pause");
}