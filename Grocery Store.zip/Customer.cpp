#include "Customer.h"


string Customer::getCustomerCNIC() {
	return customer_cnic; 
}

string Customer::getCustomerGender() {
	return customer_gender;
}
string Customer::getCustomerPhone() { 
	return customer_phone;
}
string Customer::getCustomerAddress() {
	return customer_address; 
}

void Customer::setCustomerCNIC(string cnic) {
	customer_cnic = cnic; 
}

void Customer::setCustomerGender(string gender) {
	customer_gender = gender;
}
void Customer::setCustomerPhone(string phone) { 
	customer_phone = phone; 
}
void Customer::setCustomerAddress(string address) {
	customer_address = address; 
}