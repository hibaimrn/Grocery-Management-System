﻿#include "Menu.h"
#include "Customer.h"
#include "Manager.h"
#include "Admin.h"
#include"Store.h"
#include "OnlineShopping.h"

using namespace std;
void Menu:: displayMainMenu() {

    cout << "\n\n";
    cout << "\t\t-----------------------------------------------------------------------------------------\n";
    cout << "\t\t|\t\t\t\t\t\t\t\t\t\t\t|\n\t\t|\t\t\t\t\t\t\t\t\t\t\t|\n\t\t|\t\t\t\t\t\t\t\t\t\t\t|\n\t\t|\t\t\t\t\t\t\t\t\t\t\t|";
    cout<<" \n\t\t|\t\t\tWELCOME TO THE GROCERY STORE MANAGEMENT SYSTEM\t\t\t| \n";
    cout << "\t\t|\t\t\tI HOPE YOU HAVE A LOVELY EXPERIENCE SHOPPING\t\t\t|\n\t\t|\t\t\t\t\tWITH US\t\t\t\t\t\t|\n";
    cout << "\t\t-----------------------------------------------------------------------------------------\n";
    cout << "\n\n\n\n\t\t\t\t\t ACHAA MIYARRR MAGAR SASTI QIMATEIN!!!\n";
    cout << "\t\t\t\t----------------------------------------------------\n";
    cout << "\t\t\t\t\t   AAP KA ITEMAD HAMARI ZIMADARI!!!\n";
    cout << "\t\t\t\t----------------------------------------------------\n";
    system("Color E4");
    cout << "Press Enter to continue:";
    _getch();
    ClearScreen();
    cout << "\n\n\n\t\t\t\t----------------------------------------------------\n";
    cout << "\t\t\t\t\t\tWELCOME TO THE MAIN MENU\n";
    cout << "\t\t\t\t----------------------------------------------------\n";
    cout << "\t\t\t\t\t1. Registration" << endl;
    cout << "\t\t\t\t\t2. Login" << endl;
    cout << "\t\t\t\t\t3. Home Screen & Sub Menus" << endl;
    cout << "\t\t\t\t\t4. Exit" << endl;
    int choice;
    std::cout << "Enter your choice:";
    std::cin >> choice;
    ClearScreen();
    switch (choice) {
    case 1:
        displayRegisterMenu();
        
    case 2:
        displayLoginMenu();
        break;
    case 3:
        displayMainMenu();
        break;
    case 4:
        break;
    default:
        cout << "Invalid Input";
        break;
    }
}
    void Menu:: displayLoginMenu(){
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE LOGIN MENU\n";
        cout << "\t\t\t\t----------------------------------------------------\n\n\n";
        std::cout << "\t\t\t\t\t1.Login Admin\n";
        std::cout << "\t\t\t\t\t2.Login Manager\n";
        std::cout << "\t\t\t\t\t3.Login Customer\n";
        int choice;
        std::cout << "\t\t\t\tEnter your choice:";
        std::cin >> choice;
        ClearScreen();
        switch (choice) {
        case 1:
           adminLogin();
           break;
        case 2:
            managerLogin();
            break;
        case 3:
            customerLogin();
            break;

        }
    }
    void Menu::displayRegisterMenu() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE REGISTER MENU\n";
        cout << "\t\t\t\t----------------------------------------------------\n\n\n";
        std::cout << "\t\t\t\t1.Register Manager\n";
        std::cout << "\t\t\t\t2.Register Customer\n";
        int choice;
        std::cout << "Enter your choice:";
        std::cin >> choice;
        switch (choice) {
        case 1:
            cout << "\t\t\t\t----------------------------------------------------\n";
            cout << "\t\t\t\t|ONLY ADMIN CAN REGISTER A MANAGER!!                |"<<endl;
            cout << "\t\t\t\t----------------------------------------------------\n\n";
            cout << "\t\t\t\tLOGIN AS ADMIN OR EXIT!\n";
            int ch;
            cout << "\t\t\t\tPRESS 1 FOR LOGIN AS ADMIN AND 2 FOR EXIT\n";
            cin >> ch;
            if (ch==1){
                adminLogin();
            }
            if (ch == 2) {
                break;
            }
            break;
        case 2:
            registerCustomer();
            break;

        }
   }
    void Menu:: adminLogin() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE ADMIN LOGIN\n";
        cout << "\t\t\t\t----------------------------------------------------\n";
        Admin admin;
        string adminUsername;
        string adminPassword;

        cout << "Enter Username: ";
        cin >> adminUsername;
        cout << "Enter Password: ";
        cin >> adminPassword;
        bool isValid = true;
        
        ifstream myFile("Admin.bin", ios::binary);
        while (myFile.read((char*)&admin, sizeof(admin))) {
            if (admin.getname() == adminUsername && admin.getpassword() == adminPassword) {
                isValid = true;
                myFile.close();
            }
        }

        if (adminUsername == "Admin"&& adminPassword=="Admin1234")
        {
            ClearScreen();
            cout << "\t\t\t\tSUCCESSFULLY LOGGED IN!!\n\t\t\t\tWELCOME BACK ADMIN!!!\n";
            adminMenu();
            int choice;
            cin >> choice;
            switch (choice) {
            case 1:
                registerManager();
                break;
            case 2:
                admin.manageStoresAndUsers();
                break;
            case 3:
                admin.manageProductCatalog();
                break;
            case 4:
                admin.addProduct();
                break;
            case 5:
                admin.deleteProduct();
                break;
            case 6:
                admin.searchProduct();
                break;
            default:
                cout << "Invalid input";
                break;
            }
        }
        else
        {
            cout << "Invalid credentials." << endl;
        }
        displayMainMenu();
    }
    void Menu:: managerLogin() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE MANAGER LOGIN\n";
        cout << "\t\t\t\t----------------------------------------------------\n\n\n";
        Manager manager;
        string managerUsername;
        string managerPassword;

        cout << "Enter Username: ";
        cin >> managerUsername;
        cout << "Enter Password: ";
        cin >> managerPassword;
        bool isValid = true;
        ifstream myFile("Manager.bin", ios::binary);
        while (myFile.read((char*)&manager, sizeof(manager))) {
            if (manager.getname() == managerUsername && manager.getpassword() == managerPassword) {
                isValid = true;
                myFile.close();
            }
        }

        if (isValid)
        {
            ClearScreen();
            cout << "\t\t\t\tSUCCESSFULLY LOGGED IN!!\n\t\t\t\tWELCOME BACK MANAGER!!!\n";
            managerMenu();
            int choice;
            cin >> choice;
            switch (choice) {
            case 1:
               manager.addInventory();
              
                break;
            case 2:
               manager.deleteInventory();
                break;
            case 3:
               manager.searchInventory();
                break;
            case 4:
                break;
            default:
                cout << "Invalid input";
                break;
            }
        }
        else
        {
            cout << "Invalid credentials." << endl;
        }
        displayMainMenu();
    }

    void Menu::customerLogin() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE CUSTOMER LOGIN\n";
        cout << "\t\t\t\t----------------------------------------------------\n";
        Customer customer;
        string customerUsername;
        string customerPassword;

        cout << "Enter Username: ";
        cin >> customerUsername;
        cout << "Enter Password: ";
        cin >> customerPassword;

      
        bool isValid = true;
       
        ifstream myFile("Customer.bin", ios::binary);
        while (myFile.read((char*)&customer, sizeof(customer))) {
            if (customer.getname() == customerUsername && customer.getpassword() == customerPassword) {
                isValid = true;
                myFile.close();
            }
        }



        if (isValid)
        {
            ClearScreen();
            customerMenu();
            int choice;
            cin >> choice;
            OnlineShopping o;
            switch (choice) {
            case 1:
                o.addToCart();

                break;
            case 2:
                o.showCart();
                break;
            case 3:
                o.checkoutandpayment();
                break;
            case 4:
                o.feedback();
                break;
            case 5:
                break;
            default:
                cout << "Invalid input";
                break;
            }

        }
        else
        {
            cout << "Invalid credentials." << endl;
        }
        displayMainMenu();
    }

    void Menu::registerCustomer() {
        cout << "\t\t\t\t\t\tWELCOME TO THE REGISTER CUSTOMER\n\n";
        Customer customer;
        string name;
        string cnic;
        string password;
        string rePassword;
        string gender;
        string phone;
        string address;
        bool valid = false;
        cout << "Enter your name:";
        cin >> name;
        while (!valid) {
            cout << "Enter 13-digit CNIC: ";
            cin >> cnic;
            if (cnic.length() == 13) {
                valid = true;
            }
            else {
                cout << "Invalid CNIC!" << endl;
            }
        }

        valid = false;
        while (!valid) {
            cout << "Enter password: ";
            cin >> password;
            if (password.length() >= 9) {
                int upperCase = 0;
                int numeric = 0;
                for (int i = 0; i < password.length(); i++) {
                    if (isupper(password[i])) {
                        upperCase++;
                    }
                    if (isdigit(password[i])) {
                        numeric++;
                    }
                }
                if (upperCase > 0 && numeric > 0) {
                    valid = true;
                }
                else {
                    cout << "Password must contain at least one uppercase letter and one numeric digit!" << endl;
                }
            }
            else {
                cout << "Password must be at least 9 characters long!" << endl;
            }
        }

        valid = false;
        while (!valid) {
            cout << "Re-enter password: ";
            cin >> rePassword;
            if (password == rePassword) {
                valid = true;
            }
            else {
                cout << "Passwords don't match!" << endl;
            }
        }

        cout << "Enter gender: ";
        cin >> gender;
        cout << "Enter phone number: ";
        cin >> phone;
        cout << "Enter address: ";
        cin.ignore();
        getline(cin, address);
        customer.setname(name);
        customer.setCustomerCNIC(cnic);
        customer.setpassword(password);
        customer.setCustomerGender(gender);
        customer.setCustomerPhone(phone);
        customer.setCustomerAddress(address);

        ofstream myFile("Customer.bin", ios::binary | ios::app);
        if (myFile.write((char*)&customer, sizeof(customer))) {
        cout << "Registration successful!" << endl;
        customerLogin();
    }
        else
            cout << "Unsuccessful Registeration!" << endl;
        myFile.close();

    }

    void Menu:: registerManager() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tWELCOME TO THE REGISTER MANAGER\n";
        cout << "\t\t\t\t----------------------------------------------------\n\n\n";
        Manager manager;
        string managerID;
        string password;
        string rePassword;
        Store store;
        string storeName;
        string storeManager;
        string storeLocation;
        bool valid = false;

        while (!valid) {
            cout << "Enter manager ID: ";
            cin >> managerID;
            if (managerID.length() >= 8) {
                valid = true;
            }
            else {
                cout << "Manager ID must be at least 8 characters long!" << endl;
            }
        }

        valid = false;
        while (!valid) {
            cout << "Enter password: ";
            cin >> password;
            if (password.length() >= 9) {
                int upperCase = 0;
                int numeric = 0;
                for (int i = 0; i < password.length(); i++) {
                    if (isupper(password[i])) {
                        upperCase++;
                    }
                    if (isdigit(password[i])) {
                        numeric++;
                    }
                }
                if (upperCase > 0 && numeric > 0) {
                    valid = true;
                }
                else {
                    cout << "Password must contain at least one uppercase letter and one numeric digit!" << endl;
                }
            }
            else {
                cout << "Password must be at least 9 characters long!" << endl;
            }
        }

        valid = false;
        while (!valid) {
            cout << "Re-enter password: ";
            cin >> rePassword;
            if (password == rePassword) {
                valid = true;
            }
            else {
                cout << "Passwords don't match!" << endl;
            }
        }

        cout << "Enter store name: ";
        cin >> storeName;
        cout << "Enter store manager: ";
        cin >> storeManager;
        cout << "Enter store location: ";
        cin >> storeLocation;

        store.setStoreName(storeName);
        store.setStoreManager(storeManager);
        store.setStoreLocation(storeLocation);

        manager.setname(managerID);
        manager.setpassword(password);
        manager.setStore(store);


        ofstream myFile("Manager.bin", ios::binary | ios::app);
        if (myFile.write((char*)&manager, sizeof(manager))) {
            cout << "Registration successful!" << endl;
            managerLogin();
        }
        else
            cout << "Unsuccessful Registeration!"<<endl;
        myFile.close();
        
    }
  
    void Menu::adminMenu() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t|\t\tWELCOME TO THE ADMIN'S MENU        |\n";
        cout << "\t\t\t\t----------------------------------------------------\n\n";
        cout << "\t\t\t\tAdmin Logged in Successfully!!\n" << endl;
        cout << "\t\t\t\tAdmin Menu:"<<endl;
        cout << "\t\t\t\t1.Register Manager" << endl;
        cout << "\t\t\t\t2.Manage stores and users" << endl;
        cout << "\t\t\t\t3.Manage product catalog" << endl;
        cout << "\t\t\t\t4.Add Product" << endl;
        cout << "\t\t\t\t5.Delete Product" << endl;
        cout << "\t\t\t\t6.Search Product" << endl;
    }
    void Menu::customerMenu() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tCustomer Logged in Successfully." << endl;
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "Customer Menu:" << endl;
        cout << "1.Add to Cart" << endl;
        cout << "2.Show Cart" << endl;
        cout << "3.Checkout and Payments" << endl;
        cout << "4.Feedbeck" << endl;
        cout << "5.Exit" << endl;
    }
    void Menu::managerMenu() {
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "\t\t\t\t\t\tManager Logged in Successfully." << endl;
        cout << "\t\t\t\t----------------------------------------------------\n";
        cout << "Manager Menu:" << endl;
        cout << "1.Add to Inventory" << endl;
        cout << "2.Delete from Inventory" << endl;
        cout << "3.Search Inventory" << endl;
        cout << "4.Exit" << endl;
    }
   
    void Menu::ClearScreen() { system("cls"); }