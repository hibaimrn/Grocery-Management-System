#pragma once
#include<iostream>
#include <fstream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <conio.h>
using namespace std;
class Menu
{
	public:
	void displayMainMenu();
	void ClearScreen(); 
	void displayLoginMenu();
	void adminLogin();
	void managerLogin();
	void customerLogin();
	void displayRegisterMenu();
	void  registerManager();
	void  registerCustomer();
	void adminMenu();
	void customerMenu();
	void managerMenu();

};

