#include "User.h"
void User::setname(string name) {
	name = name;
}
void User::setpassword(string password) {
	password = password;
}
string User::getname() {
	return name;
}
string User::getpassword() {
	return password;
}