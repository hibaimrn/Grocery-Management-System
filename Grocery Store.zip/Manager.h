#pragma once
#include"Store.h"
#include "Inventory.h"
#include<string>
#include "Menu.h"
#include "User.h"
#include <fstream>
using namespace std;
class Manager :public User
{
private:
private:
    Store store;
public:  
    Store getStore();
    void setStore(Store s);
    void addInventory();
    void deleteInventory();
    void searchInventory();
};

