#include "OnlineShopping.h"
#include "Menu.h"
#include"fstream"
#include "Payment.h"
using namespace std;
void OnlineShopping::addToCart() {
    Menu m;
    ProductCatalog p;
    int price{};
 {} int quantity{};
    string name;
    int choice;
    
    p.setData(name, quantity, price);
      
    for (int i = 0; i < 20; i++) {
        ofstream write;
        write.open("products.txt", ios::app);
        cout << "-------------------------------------" << endl;
        std::cout << "1.Enter Product in Cart \n2.To Exit Cart\n3.Show Cart " << endl;
        std::cin >> choice;
        switch (choice) {
        case 1:

            std::cout << "Enter Product name:";
            std::cin >> name;
            std::cout << "Enter Product quantity:";
            std::cin >> quantity;
            std::cout << "Enter Product price:";
            std::cin >> price;
            write << name << "\t" << quantity << "\t" << price << endl;
            write.close();
            break;

        case 2:
            break;
        case 3:
            showCart();
            break;
        }
    }
     
    m.customerLogin();
}
void OnlineShopping::showCart() {
    Menu m;
    ifstream read;
    read.open("products.txt");
    string a, b, c;
    while (read >> a >> b >> c)
    {
        std::cout << a << "\t" << b << "\t" << c << endl;
    }
    read.close();
    m.customerLogin();
}
void OnlineShopping::feedback() {
    string feedback;

    std::cout << "\t\t\t\tI HOPE YOU HAD A LOVELY EXPERINCE SHOPPING WITH US!" << endl;
    std::cout << "\t\t\t\tYOUR FEEDBACK MATTER!" << endl;
    std::cout << "\t\t\t\tEnter Your Feedback" << endl;
    std::cin.ignore();
    std::getline(std::cin, feedback);

    fstream f;
    f.open("feedback.txt", ios::out | ios::app);
    f << feedback << "\n";
    f.close();
    std::cout << "\t\t\t\tThanks for the feedback.\nHope to see you soon!\nTAKE CARE\n";
}
void OnlineShopping::checkoutandpayment(){
    
    Menu m;
    int charge, extra;
    int choice;
    std::cout << "Enter the total amount to pay: ";
    std::cin >> charge;
    std::cout << "Select the payment option:\n1. Cash on Delivery\n2. Debit/Credit Card\n3. Easypaisa\n4. Jazz cash\n";
    std::cin >> choice;
    Payment p;
    switch (choice)
    {
    case 1:
    {    
        cout << "Are you in the same city as the store? (Enter 1 for Yes and 0 for No): ";
        cin >> extra;
        if (extra == 1)
            extra = 30;
        else
            extra = 50;
        p.COD(charge, extra);
        break;
    }
    case 2:
    {
        p.Debit_Credit(charge);
        break;
    }
    case 3:
    {
       p.Easypaisa(charge);
        break;
    }
    case 4:
    {
        p.Jazz_cash(charge);
        break;
    }
    default:
        cout << "Invalid input!\n";
        break;
    }

    cout << "Would you like to Exit or Continue to App!\n\n" << endl;
    int option=0;
    cout << "1.Exit\n2.Customer Menu\n";
    cin >> option;
    switch (option) {
    case 1:
        exit;
        break;
    case 2:
        m.customerLogin();
        break;
    }
}

