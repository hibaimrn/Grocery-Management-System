#pragma once
#include <iostream>
#include <string>
#include "ProductCatalog.h"
#include <fstream>
#include "Payment.h"
using namespace std;
class OnlineShopping
{
    private:
        ProductCatalog products[20];
        int size;
        double total;
    public:
        OnlineShopping() {
            size = 0;
            total = 0;
        }
        void addToCart();
        void showCart();
        void feedback();
        void checkoutandpayment();
       

    };


