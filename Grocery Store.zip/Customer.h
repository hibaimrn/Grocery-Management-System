#pragma once
#include<string>
#include "User.h"
using namespace std;
class Customer :public User
{
private: 
    string customer_cnic;
    string customer_gender;
    string customer_phone;
    string customer_address;
public:
    string getCustomerCNIC();
    string getCustomerGender();
    string getCustomerPhone();
    string getCustomerAddress();
   
    void setCustomerCNIC(string cnic);
    
    void setCustomerGender(string gender);
    void setCustomerPhone(string phone);
    void setCustomerAddress(string address);
};

