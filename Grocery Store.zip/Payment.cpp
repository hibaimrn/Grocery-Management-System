#include "Payment.h"
void Payment::COD(int charge, int extra)
{
    int total_charge;
    total_charge = charge + extra;
    cout << "Payment via Cash on Delivery.\n";
    cout << "Total amount to be paid: " << total_charge << endl;
}

void Payment::Debit_Credit(int charge)
{
    cout << "Payment via Debit/Credit Card.\n";
    cout << "Total amount to be paid: " << charge << endl;
}

void Payment::Easypaisa(int charge)
{
    cout << "Payment via Easypaisa.\n";
    cout << "Total amount to be paid: " << charge << endl;
}

void Payment::Jazz_cash(int charge)
{
    cout << "Payment via Jazz cash.\n";
    cout << "Total amount to be paid: " << charge << endl;
}
