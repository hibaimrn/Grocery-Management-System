#pragma once
#include<iostream>
#include<string>
using namespace std;
class User
{
public:
	string name;
	string password;
	void setname(string name);
	void setpassword(string password);
	string getname();
	string getpassword();
};

