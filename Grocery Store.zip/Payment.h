#pragma once
#include <iostream>
#include"OnlineShopping.h"
using namespace std;
class Payment
{   public:
    void COD(int charge, int extra);
    void Debit_Credit(int charge);
    void Easypaisa(int charge);
    void Jazz_cash(int charge);
};

