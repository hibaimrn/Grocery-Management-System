#include "Admin.h"
#include <string>

void Admin::addProduct() {
    Menu m;
    fstream f;
    ProductCatalog p;

    f.open("product.txt", ios::out | ios::app);
    f << p.getId() << " " << p.getPrice() << " " << p.getQuantity() << " " << p.getName() << "\n";
    f.close();
    m.adminLogin();
}
void Admin::deleteProduct() {
    Menu m;
    fstream f;
    int id;
    cout << "Enter Product ID";
    cin >> id;
    f.open("product.txt", ios::in);
    fstream f1;
    f1.open("temp.txt", ios::out);
    int c;
    string line;
    while (getline(f, line)) {
        int j = 0;
        string s = "";
        for (int i = 0; i < line.size(); i++) {
            if (line[i] == ' ') {
                c = stoi(s);
                if (c != id) {
                    f1 << line << "\n";
                    break;
                }
                else {
                    s = "";
                    break;
                }
            }
            else {
                s += line[i];
            }
        }
    }
    f.close();
    f1.close();
    remove("product.txt");
    rename("temp.txt", "product.txt");
    m.adminLogin();
}
void Admin::searchProduct() {
    Menu m;
    fstream f;
    int id;
    cout << "Enter Product ID";
    cin >> id;
    f.open("product.txt", ios::in);
    int c;
    string line;
    while (getline(f, line)) {
        int j = 0;
        string s = "";
        ProductCatalog p;
        for (int i = 0; i < line.size(); i++) {
            if (line[i] == ' ') {
                c = stoi(s);
                if (c == id) {
                    p.setId(c);
                    s = "";
                }
                else {
                    s = "";
                    break;
                }
            }
            else {
                s += line[i];
            }
        }
    }
    f.close();
    m.adminLogin();
}
void Admin::manageStoresAndUsers()
{
    Menu m;
    string storeName;
    string storeLocation;
    string managerName;
    string managerLocation;

    cout << "Enter store name: ";
    cin >> storeName;
    cout << "Enter store location: ";
    cin >> storeLocation;
    cout << "Enter manager name: ";
    cin >> managerName;
    cout << "Enter manager location: ";
    cin >> managerLocation;

    ofstream storeManagerFile("store_manager.txt", ios::out);
    storeManagerFile << storeName << endl;
    storeManagerFile << storeLocation << endl;
    storeManagerFile << managerName << endl;
    storeManagerFile << managerLocation << endl;
    storeManagerFile.close();
    m.adminLogin();
}
void Admin::manageProductCatalog()
{
    Menu m;
    string productName;
    string productCategory;
    double productPrice;

    cout << "Enter product name: ";
    cin >> productName;
    cout << "Enter product category: ";
    cin >> productCategory;
    cout << "Enter product price: ";
    cin >> productPrice;

    ofstream productFile("product_catalog.txt", ios::out);
    productFile << productName << endl;
    productFile << productCategory << endl;
    productFile << productPrice << endl;
    productFile.close();
    m.adminLogin();
}